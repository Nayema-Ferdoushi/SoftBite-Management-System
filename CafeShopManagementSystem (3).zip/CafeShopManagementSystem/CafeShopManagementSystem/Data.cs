﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CafeShopManagementSystem
{
    class Data
    {
        public static string username;
    }
}
